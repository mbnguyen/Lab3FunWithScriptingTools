Name: Minh Binh Nguyen
PantherID: 002-46-4288

FUN WITH SCRIPTING TOOLS

Part 1:
  Please give the permission to execute to the file named script.sh
by running "chmod 777 script.sh"

  Then run the script.sh (command "./script.sh")

  The outputs of the scripts are saved in the files with the format "questionX.txt"
where X is the number of the question.

Part 2:
  Please give the permission to execute to the file named string2knuts.sh and knuts2string.sh
and sum.sh by running "chmod 777 string2knuts.sh" and "chmod 777 knuts2string.sh" and 
"chmod 777 sum.sh"

  Then run the script string2knuts.sh (./string2knuts.sh). The output is saved in out1.txt.

  Next, run the script knuts2string.sh (./knuts2string.sh). The output is saved in out2.txt.

  Finally, run the script sum.sh (./sum.sh).



